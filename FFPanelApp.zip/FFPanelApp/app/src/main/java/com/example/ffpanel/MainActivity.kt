package com.example.ffpanel

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {
    data class Item(val name: String, val dir: Boolean)

    private val items = mutableListOf<Item>()
    private var sub = ""
    private var pending: List<Uri> = emptyList()
    private lateinit var etPath: EditText
    private lateinit var tvInfo: TextView
    private lateinit var adapter: ArrayAdapter<String>

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { load() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { load() } }

    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) install(uris)
    }

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    // Jalankan perintah shell lewat Shizuku
    private fun sh(cmd: String): Pair<Int, String> {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "{ $cmd; } 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        return p.waitFor() to out
    }

    private fun dir(): String {
        val base = etPath.text.toString().trim().trimEnd('/')
        return if (sub.isEmpty()) base else "$base/$sub"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        etPath = EditText(this).apply {
            setText(getSharedPreferences("p", 0).getString("path", "/sdcard/Android/data/com.dts.freefiremax/files")); setSingleLine()
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(btn("Izin") {
            try {
                if (!Shizuku.pingBinder()) toast("Aktifkan Shizuku dulu")
                else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(1)
                else toast("Izin sudah ada")
            } catch (e: Throwable) { toast("Aktifkan Shizuku dulu") }
        })
        row.addView(btn("Pasang File") { pick.launch(arrayOf("*/*")) })
        row.addView(btn("Refresh") { sub = ""; load() })
        tvInfo = TextView(this)
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        list.adapter = adapter
        root.addView(etPath); root.addView(row); root.addView(tvInfo); root.addView(list)
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ ->
            val it = items[pos]
            if (it.dir) {
                sub = if (it.name == "..") sub.substringBeforeLast('/', "") else if (sub.isEmpty()) it.name else "$sub/${it.name}"
                load()
            }
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val it = items[pos]
            if (it.name != "..") AlertDialog.Builder(this)
                .setTitle("Hapus?").setMessage(it.name)
                .setPositiveButton("Hapus") { _, _ -> delete(it.name) }
                .setNegativeButton("Batal", null).show()
            true
        }
        addOnNewIntentListener { handle(it) }
        handle(intent)
        load()
    }

    // Terima file dari 'Bagikan' / 'Buka dengan' aplikasi lain, langsung dipasang
    private fun handle(i: Intent?) {
        i ?: return
        val list = mutableListOf<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.addAll(it) }
            Intent.ACTION_VIEW -> i.data?.let { list.add(it) }
        }
        if (list.isNotEmpty()) { pending = list; load() }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun load() {
        getSharedPreferences("p", 0).edit().putString("path", etPath.text.toString().trim()).apply()
        tvInfo.text = when {
            !try { Shizuku.pingBinder() } catch (e: Throwable) { false } -> "Shizuku belum aktif. Buka Shizuku lalu Start."
            !ready() -> "Izin Shizuku belum diberikan. Tekan tombol Izin."
            else -> "Siap • " + dir()
        }
        if (!ready()) { items.clear(); render(); return }
        if (pending.isNotEmpty()) { val u = pending; pending = emptyList(); install(u); return }
        val p = dir()
        Thread {
            val res = try {
                sh("[ -d ${q(p)} ] || exit 3; cd ${q(p)} && stat -c '%F|%s|%n' * .[!.]* 2>/dev/null; exit 0")
            } catch (e: Throwable) { -1 to (e.message ?: "error") }
            val list = mutableListOf<Item>()
            if (sub.isNotEmpty()) list.add(Item("..", true))
            if (res.first == 0) res.second.lines().forEach { ln ->
                val t = ln.split("|", limit = 3)
                if (t.size == 3) list.add(Item(t[2], t[0].contains("directory")))
            }
            runOnUiThread {
                if (res.first == 3) tvInfo.text = "Folder tidak ada. Buka Free Fire Max sekali dulu."
                else if (res.first != 0) tvInfo.text = "Error: " + res.second.take(120)
                items.clear(); items.addAll(list.sortedWith(compareBy({ !it.dir }, { it.name.lowercase() }))); render()
            }
        }.start()
    }

    private fun render() {
        adapter.clear()
        adapter.addAll(items.map { (if (it.dir) "📁 " else "📄 ") + it.name })
    }

    private fun delete(name: String) {
        val target = dir() + "/" + name
        Thread {
            val r = try { sh("rm -rf ${q(target)}") } catch (e: Throwable) { -1 to (e.message ?: "") }
            runOnUiThread { toast(if (r.first == 0) "Dihapus" else "Gagal: ${r.second}"); load() }
        }.start()
    }

    private fun nameOf(u: Uri): String {
        contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i).substringAfterLast('/')
        }
        return "file_" + System.currentTimeMillis()
    }

    private fun install(uris: List<Uri>) {
        if (!ready()) { toast("Aktifkan Shizuku dan beri izin dulu"); return }
        val p = dir()
        Thread {
            var ok = 0; var err = ""
            uris.forEach { u ->
                try {
                    val name = nameOf(u)
                    val tmp = File(externalCacheDir ?: cacheDir, "up.tmp")
                    contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    val r = sh("mkdir -p ${q(p)} && cp -f ${q(tmp.absolutePath)} ${q("$p/$name")}")
                    tmp.delete()
                    if (r.first == 0) ok++ else err = r.second
                } catch (e: Throwable) { err = e.message ?: "error" }
            }
            runOnUiThread { toast(if (err.isEmpty()) "$ok file dipasang" else "Gagal: $err"); load() }
        }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
